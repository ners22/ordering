<?php
session_start();

// Remove cart session
unset($_SESSION['cart']);

// Redirect to menu page
header("Location: menu.php");
exit;
?>
