// Fetch all categories
$sql = "SELECT * FROM categories";
$result = $conn->query($sql);
$categories = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
</head>
<body>
    <h1>Manage Categories</h1>

    <!-- Add Category Form -->
    <h2>Add New Category</h2>
    <form action="manage_categories.php" method="POST">
        <label for="name">Category Name: </label>
        <input type="text" name="name" required><br>

        <label for="description">Description: </label>
        <textarea name="description" required></textarea><br>

        <button type="submit" name="add_category">Add Category</button>
    </form>

    <hr>

    <!-- Edit Category Form (hidden by default) -->
    <h2>Edit Category</h2>
    <form action="manage_categories.php" method="POST" id="edit_form" style="display: none;">
        <input type="hidden" name="id" id="edit_id">
        <label for="edit_name">Category Name: </label>
        <input type="text" name="name" id="edit_name" required><br>

        <label for="edit_description">Description: </label>
        <textarea name="description" id="edit_description" required></textarea><br>

        <button type="submit" name="edit_category">Update Category</button>
    </form>

    <hr>

    <!-- List of Categories -->
    <h2>Existing Categories</h2>
    <table border="1">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($categories as $category): ?>
                <tr>
                    <td><?= $category['id'] ?></td>
                    <td><?= $category['name'] ?></td>
                    <td><?= $category['description'] ?></td>
                    <td>
                        <a href="javascript:void(0);" onclick="editCategory(<?= $category['id'] ?>, '<?= $category['name'] ?>', '<?= $category['description'] ?>')">Edit</a> |
                        <a href="manage_categories.php?delete=<?= $category['id'] ?>" onclick="return confirm('Are you sure you want to delete this category?')">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <script>
        function editCategory(id, name, description) {
            // Show the edit form and populate it with the existing category data
            document.getElementById('edit_form').style.display = 'block';
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_description').value = description;
        }
    </script>

</body>
</html>
