<?php
session_start();

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    echo json_encode(['error' => 'Cart not found']);
    exit;
}

if (isset($_POST['index']) && isset($_POST['quantity'])) {
    $index = intval($_POST['index']);
    $quantity = intval($_POST['quantity']);
    
    if ($quantity < 1) $quantity = 1;

    if (isset($_SESSION['cart'][$index])) {
        $_SESSION['cart'][$index]['quantity'] = $quantity;
    }

    $total_price = 0;
    $total_quantity = 0;

    foreach ($_SESSION['cart'] as $item) {
        if (is_array($item) && isset($item['price'], $item['quantity'])) {
            $total_price += $item['price'] * $item['quantity'];
            $total_quantity += $item['quantity'];
        }
    }

    $subtotal = $_SESSION['cart'][$index]['price'] * $_SESSION['cart'][$index]['quantity'];

    echo json_encode([
        'subtotal' => $subtotal,
        'total_price' => $total_price,
        'total_quantity' => $total_quantity
    ]);
} else {
    echo json_encode(['error' => 'Invalid request']);
}
