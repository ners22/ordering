<?php
session_start();
include 'config.php';

// Fetch pending orders
$order_result = $conn->query("SELECT * FROM orders WHERE order_status = 'pending'");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Pending Orders</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; background-color: #121212; color: white; padding: 20px; }
        h2 { color: #ffa31a; font-size: 36px; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border: 1px solid #333; text-align: left; }
        th { background-color: #1a1a1a; color: #ffa31a; }
        tr:hover { background-color: #333; }
        .back-btn { display: inline-block; margin-top: 10px; padding: 10px 20px; background: #264653; color: white; text-decoration: none; font-weight: bold; }
        .back-btn:hover { background-color: #ffa31a; color: black; }
    </style>
</head>
<body>

<h2>Pending Orders</h2>

<table>
    <tr>
        <th>Order ID</th>
        <th>User ID</th>
        <th>Order Status</th>
        <th>Created At</th>
    </tr>
    <?php while ($row = $order_result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['user_id']) ?></td>
            <td><?= htmlspecialchars($row['order_status']) ?></td>
            <td><?= htmlspecialchars($row['created_at']) ?></td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="admin_dashboard.php" class="back-btn">Back to Dashboard</a>

</body>
</html>
