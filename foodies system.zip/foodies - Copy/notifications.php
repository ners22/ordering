<?php
session_start();
require_once 'config.php';

// Redirect to login if not logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Mark only pending payment notifications as read (optional)
mysqli_query($conn, "UPDATE notifications 
    SET status = 'read' 
    WHERE user_id = $user_id AND message LIKE '%Pending Payment%'");

// Fetch only pending payment notifications
$query = "SELECT * FROM notifications 
          WHERE user_id = $user_id 
          AND message LIKE '%Pending Payment%' 
          ORDER BY created_at DESC";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Pending Payment Notifications</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #0f0f0f;
            color: white;
            font-family: 'Nunito', sans-serif;
        }
        .container {
            margin-top: 60px;
        }
        .card {
            background-color: #1a1a1a;
            border: 1px solid #ffa31a;
        }
        .card-body {
            color: white;
        }
        .notification-time {
            font-size: 0.85em;
            color: #aaa;
            margin-top: 5px;
        }
        .btn-back {
            background-color: #ffa31a;
            color: #0f0f0f;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            padding: 10px 20px;
            margin-top: 20px;
            text-decoration: none;
            display: inline-block;
        }
        .btn-back:hover {
            background-color: #ff8c00;
            color: white;
        }
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">🔔 Pending Payment Notifications</h2>

    <?php if (mysqli_num_rows($result) > 0): ?>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <div class="card mb-3">
                <div class="card-body">
                    <?= htmlspecialchars($row['message']) ?>
                    <div class="notification-time">
                        <?= date('F j, Y - g:i A', strtotime($row['created_at'])) ?>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    <?php else: ?>
        <p class="text-center">✅ No pending payment notifications.</p>
    <?php endif; ?>

    <div class="text-center">
        <a href="index.php" class="btn-back">⬅ Back to Home</a>
    </div>
</div>

</body>
</html>
