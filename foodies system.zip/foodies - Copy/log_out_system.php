<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Online Food Ordering</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* Resetting the default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Nunito', sans-serif;
            background-color: #f7f9fc;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
        }

        header {
            width: 100%;
            background-color: #FF6F61;
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }

        header h1 {
            font-size: 30px;
            font-weight: 600;
        }

        nav {
            margin-top: 15px;
        }

        nav a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            margin: 0 15px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        nav a:hover {
            text-decoration: underline;
        }

        /* Food Section */
        .food-items {
            margin-top: 40px;
            text-align: center;
        }

        .food-items h2 {
            font-size: 24px;
            margin-bottom: 20px;
        }

        .food-card {
            display: inline-block;
            background-color: #fff;
            border-radius: 10px;
            padding: 20px;
            margin: 15px;
            width: 250px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
            text-align: center;
        }

        .food-card:hover {
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
            transform: translateY(-5px);
        }

        .food-card img {
            width: 100%;
            border-radius: 8px;
        }

        .food-card h3 {
            font-size: 20px;
            margin-top: 15px;
        }

        .food-card p {
            font-size: 16px;
            color: #777;
            margin: 10px 0;
        }

        .food-card .btn-order {
            background-color: #FF6F61;
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
            transition: background-color 0.3s ease;
        }

        .food-card .btn-order:hover {
            background-color: #e45742;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            header h1 {
                font-size: 24px;
            }

            nav a {
                font-size: 14px;
                margin: 0 10px;
            }

            .food-card {
                width: 220px;
            }
        }

        @media (max-width: 480px) {
            header {
                padding: 15px;
            }

            nav a {
                font-size: 12px;
                margin: 0 8px;
            }

            .food-card {
                width: 180px;
                padding: 15px;
            }

            .food-card h3 {
                font-size: 18px;
            }

            .food-card p {
                font-size: 14px;
            }
        }

    </style>
</head>
<body>

    <header>
        <h1>Welcome to Online Food Ordering</h1>
        <nav>
            <a href="index.php">Home</a> | 
            <a href="cart.php">View Cart</a> | 
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
            <?php endif; ?>
        </nav>
    </header>

    <div class="food-items">
        <h2>Our Delicious Food Items</h2>

        <div class="food-card">
            <img src="https://via.placeholder.com/250x150?text=Pizza" alt="Pizza">
            <h3>Delicious Pizza</h3>
            <p>Hot, cheesy pizza with your favorite toppings!</p>
            <a href="order.php?item=pizza" class="btn-order">Order Now</a>
        </div>

        <div class="food-card">
            <img src="https://via.placeholder.com/250x150?text=Burger" alt="Burger">
            <h3>Juicy Burger</h3>
            <p>A freshly grilled burger with all the fixings.</p>
            <a href="order.php?item=burger" class="btn-order">Order Now</a>
        </div>

        <div class="food-card">
            <img src="https://via.placeholder.com/250x150?text=Pasta" alt="Pasta">
            <h3>Italian Pasta</h3>
            <p>Perfectly cooked pasta with a savory sauce.</p>
            <a href="order.php?item=pasta" class="btn-order">Order Now</a>
        </div>

        <div class="food-card">
            <img src="https://via.placeholder.com/250x150?text=Sushi" alt="Sushi">
            <h3>Fresh Sushi</h3>
            <p>Delicious sushi rolls with fresh fish.</p>
            <a href="order.php?item=sushi" class="btn-order">Order Now</a>
        </div>
    </div>

</body>
</html>
