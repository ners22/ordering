<?php
session_start();
include 'config.php'; // connect to your DB

$success = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $address = trim($_POST["address"]);
    $password = $_POST["password"];
    $confirm_password = $_POST["confirm_password"];

    // Username validation
    if (strlen($username) < 6 || strtolower($username) === '123') {
        $error = "Username must be at least 6 characters and not '123'.";
    }
    // Email validation
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL) ||
        preg_match('/^(123|aaa|bbb)@/i', $email)) {
        $error = "Please enter a valid email address (not starting with 123@, aaa@, or bbb@).";
    }
    // Password validation
    else if (strlen($password) < 8 || strtolower($password) === '123' ||
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password) ||
        !preg_match('/[0-9]/', $password) ||
        !preg_match('/[^a-zA-Z0-9]/', $password)) {
        $error = "Password must be at least 8 characters, not '123', and include uppercase, lowercase, number, and special character.";
    }
    // Check if passwords match
    else if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error = "Username or email already exists.";
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);

            // Insert into users table (role = customer by default)
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, 'customer')");
            $stmt->bind_param("sss", $username, $email, $hashed_password);

            if ($stmt->execute()) {
                $success = "Registration successful! You can now log in.";
                header("Refresh:2; url=login.php");
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - FoodieHub</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        /* SAME STYLES YOU PROVIDED */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Roboto', sans-serif;
            background: url("uploads/stir-fry-recipe.jpg") no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: white;
        }
        .signup-container {
            background: rgba(0, 0, 0, 0.8);
            padding: 40px;
            border-radius: 10px;
            width: 400px;
            box-shadow: 0px 5px 15px rgba(255, 152, 0, 0.3);
            text-align: center;
            animation: slideDown 0.6s ease-out;
        }
        h1 {
            font-size: 28px;
            font-weight: 600;
            color: #ff9800;
        }
        .form-group {
            margin-bottom: 20px;
            position: relative;
            text-align: left;
        }
        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
            color: #bbb;
        }
        input {
            width: 100%;
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: none;
            background: #333;
            color: white;
            transition: 0.3s;
        }
        input:focus {
            outline: none;
            background: #444;
        }
        button {
            width: 100%;
            padding: 12px;
            background: #ff9800;
            border: none;
            color: black;
            font-size: 18px;
            font-weight: bold;
            border-radius: 5px;
            cursor: pointer;
            transition: 0.3s;
        }
        button:hover {
            background: #ffb74d;
        }
        .login-link {
            margin-top: 15px;
            font-size: 14px;
        }
        .login-link a {
            color: #ff9800;
            text-decoration: none;
        }
        .login-link a:hover {
            text-decoration: underline;
        }
        .message {
            margin-bottom: 15px;
            font-size: 14px;
        }
        .message.success { color: #90ee90; }
        .message.error { color: #ff4d4d; }
        @keyframes slideDown {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h1>Sign Up</h1>

        <?php if ($success): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php elseif ($error): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="name">Username</label>
                <input type="text" name="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="address">Address</label>
                <input type="text" name="address" required>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" name="password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Confirm Password</label>
                <input type="password" name="confirm_password" required>
            </div>
            <button type="submit">Sign Up</button>
        </form>
        <div class="login-link">
            <p>Already have an account? <a href="login.php">Login Here</a></p>
        </div>
    </div>
</body>
</html>
