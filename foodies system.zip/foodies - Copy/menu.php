<?php
session_start();
include('config.php');

$appetizers_sql = "SELECT * FROM menu WHERE category = 'Appetizer'";
$main_sql = "SELECT * FROM menu WHERE category = 'Main Course'";
$desserts_sql = "SELECT * FROM menu WHERE category = 'Dessert'";

$appetizers_result = $conn->query($appetizers_sql);
$main_result = $conn->query($main_sql);
$desserts_result = $conn->query($desserts_sql);

$cart_count = 0;
if (isset($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Foodies - Menu</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script:wght@700&family=Playfair+Display:wght@500&family=Poppins:wght@400;700&display=swap" rel="stylesheet">
<style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        display: flex;
        flex-direction: column;
        align-items: center;
        min-height: 100vh;
        position: relative;
    }
    /* Add a dark overlay for readability */
    body::before {
        content: '';
        position: fixed;
        top: 0; left: 0; width: 100vw; height: 100vh;
        background: rgba(0,0,0,0.7);
        z-index: 0;
        pointer-events: none;
    }
    .menu-container {
        width: 95%;
        max-width: 1200px;
        background: rgba(20, 20, 20, 0.97);
        padding: 40px 30px 30px 30px;
        margin-top: 60px;
        border-radius: 18px;
        box-shadow: 0 8px 40px 0 rgba(255, 153, 0, 0.25);
        position: relative;
        z-index: 1;
    }
    .cart-btn {
        position: fixed;
        top: 30px;
        right: 40px;
        background: #ffd700;
        color: black;
        font-weight: bold;
        padding: 12px 20px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        box-shadow: 0 0 16px #ffd700;
        font-size: 18px;
        z-index: 2;
        transition: background 0.2s;
    }
    .cart-btn:hover {
        background: #ffe066;
    }
    .cart-count {
        background: red;
        color: white;
        font-size: 15px;
        font-weight: bold;
        border-radius: 50%;
        padding: 5px 10px;
        position: absolute;
        top: -10px;
        right: -10px;
        font-family: 'Playfair Display', serif;
        box-shadow: 0 0 8px #ff9800;
    }
    .filter-btns {
        text-align: center;
        margin-bottom: 30px;
        z-index: 1;
        position: relative;
    }
    .filter-btns button {
        background: #ff9800;
        color: black;
        font-weight: bold;
        padding: 10px 22px;
        margin: 7px 10px;
        border-radius: 7px;
        border: none;
        cursor: pointer;
        font-size: 16px;
        transition: 0.3s;
        box-shadow: 0 2px 8px rgba(255, 152, 0, 0.15);
    }
    .filter-btns button:hover, .filter-btns button.active {
        background: #ffc107;
        color: #222;
    }
    .category-section {
        margin-bottom: 40px;
    }
    .category-title {
        text-align: left;
        font-size: 32px;
        margin: 30px 0 18px 10px;
        color: #ffd700;
        font-family: 'Dancing Script', cursive;
        text-shadow: 1px 1px 8px #000;
        letter-spacing: 1px;
    }
    .menu-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
        gap: 28px;
    }
    .category-item {
        background: #181818;
        border-radius: 14px;
        overflow: hidden;
        cursor: pointer;
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 18px 12px 20px 12px;
        text-align: center;
        transition: transform 0.18s, box-shadow 0.18s;
        box-shadow: 0 2px 16px rgba(255, 255, 255, 0.08);
        min-height: 420px;
        position: relative;
    }
    .category-item:hover {
        transform: translateY(-6px) scale(1.04);
        box-shadow: 0 6px 24px #ff9800;
    }
    .category-item img {
        width: 100%;
        max-width: 220px;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
        margin-bottom: 14px;
        background: #333;
        box-shadow: 0 2px 8px #000a;
    }
    .item-name {
        font-size: 22px;
        font-weight: bold;
        color: #fff;
        margin-bottom: 7px;
        letter-spacing: 0.5px;
    }
    .item-desc {
        font-size: 15px;
        color: #cccccc;
        margin-bottom: 13px;
        min-height: 38px;
    }
    .item-price {
        font-family: 'Playfair Display', serif;
        font-weight: bold;
        color: #ffcc80;
        font-size: 22px;
        margin-bottom: 10px;
    }
    .overlay, .popup {
        display: none;
        position: fixed;
        z-index: 1000;
    }
    .overlay {
        top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0, 0, 0, 0.6);
    }
    .popup {
        top: 50%; left: 50%;
        transform: translate(-50%, -50%);
        background: #1a1a1a;
        padding: 28px 20px 20px 20px;
        border-radius: 14px;
        width: 340px;
        text-align: center;
        color: white;
        box-shadow: 0 0 24px #00ffcc;
    }
    .popup img {
        width: 100%;
        border-radius: 10px;
        margin-bottom: 12px;
        background: #333;
    }
    .close-btn {
        position: absolute;
        top: 12px;
        right: 18px;
        cursor: pointer;
        font-size: 22px;
        color: #00ffcc;
    }
    .add-to-cart {
        background: #00ffcc;
        color: black;
        padding: 12px 20px;
        border: none;
        border-radius: 7px;
        cursor: pointer;
        font-weight: bold;
        font-size: 16px;
        transition: background 0.3s;
        margin-top: 10px;
        box-shadow: 0 2px 8px #00ffcc44;
    }
    .add-to-cart:hover {
        background: #1affd5;
    }
    /* Back to Home button styling */
    button[onclick*="window.location.href='index.php'"] {
        position: fixed;
        top: 30px;
        left: 40px;
        background: #ff9800;
        color: black;
        font-weight: bold;
        padding: 12px 20px;
        border-radius: 8px;
        border: none;
        cursor: pointer;
        font-size: 18px;
        z-index: 2;
        box-shadow: 0 0 16px #ff9800;
        transition: background 0.2s;
    }
    button[onclick*="window.location.href='index.php'"]:hover {
        background: #ffc107;
    }
    /* Responsive tweaks */
    @media (max-width: 700px) {
        .menu-container {
            padding: 18px 4px 18px 4px;
        }
        .category-title {
            font-size: 24px;
        }
        .cart-btn, button[onclick*="window.location.href='index.php'"] {
            font-size: 15px;
            padding: 8px 12px;
        }
    }
</style>
</head>
<body>

<button onclick="window.location.href='index.php'" style="position: absolute; top: 20px; left: 20px; background: #ff9800; color: black; font-weight: bold; padding: 10px 15px; border-radius: 5px; border: none; cursor: pointer;">
⬅ Back to Home
</button>

<button class="cart-btn" onclick="window.location.href='cart.php'">
🛒 Cart <span class="cart-count" id="cart-count"><?php echo $cart_count; ?></span>
</button>

<div class="menu-container">
<h1 style="text-align: center; color:#ff9800;">Job & Grab's Menu</h1>

<div class="filter-btns">
    <button onclick="filterCategory('all')">All</button>
    <button onclick="filterCategory('appetizer')">Appetizers</button>
    <button onclick="filterCategory('main')">Main Courses</button>
    <button onclick="filterCategory('dessert')">Desserts</button>
</div>

<div id="appetizer-section" class="category-section">
    <h2 class="category-title">Appetizers</h2>
    <div class="menu-grid">
    <?php while ($item = $appetizers_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>" onerror="this.onerror=null;this.src='images/foodBg.jpg';">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
        <div style="margin-top:8px;">
            <button class="btn btn-success btn-sm" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">Add to Cart</button>
        </div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

<div id="main-section" class="category-section">
    <h2 class="category-title">Main Courses</h2>
    <div class="menu-grid">
    <?php while ($item = $main_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>" onerror="this.onerror=null;this.src='images/foodBg.jpg';">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
        <div style="margin-top:8px;">
            <button class="btn btn-success btn-sm" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">Add to Cart</button>
        </div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

<div id="dessert-section" class="category-section">
    <h2 class="category-title">Desserts</h2>
    <div class="menu-grid">
    <?php while ($item = $desserts_result->fetch_assoc()): 
        $image = !empty($item['image']) ? $item['image'] : 'default.jpg';
    ?>
    <div class="category-item">
        <img src="<?= $image ?>" alt="<?= htmlspecialchars($item['name']) ?>" onerror="this.onerror=null;this.src='images/foodBg.jpg';">
        <div class="item-name"><?= htmlspecialchars($item['name']) ?></div>
        <div class="item-desc"><?= htmlspecialchars($item['description']) ?></div>
        <div class="item-price">₱<?= number_format($item['price'], 2) ?></div>
        <div style="margin-top:8px;">
            <button class="btn btn-success btn-sm" onclick="showPopup('<?= $item['id'] ?>', `<?= htmlspecialchars($item['name']) ?>`, `<?= htmlspecialchars($item['description']) ?>`, '<?= $item['price'] ?>', '<?= $image ?>')">Add to Cart</button>
        </div>
    </div>
    <?php endwhile; ?>
    </div>
</div>

</div>

<div id="overlay" class="overlay"></div>
<div id="popup" class="popup">
    <span class="close-btn" onclick="closePopup()">&times;</span>
    <img id="popup-image" src="" alt="Food Image">
    <h2 id="popup-name"></h2>
    <p id="popup-description"></p>
    <h3 id="popup-price"></h3>
    
    <div style="display: flex; justify-content: center; align-items: center; gap: 10px; margin: 15px 0;">
        <button onclick="adjustQuantity(-1)" style="background: #ff9800; color: black; font-weight: bold; padding: 5px 10px; border-radius: 5px; border: none; cursor: pointer;">-</button>
        
        <input type="number" id="quantity" min="1" value="1" style="width: 80px; text-align: center; background: #222; color: white; border: 1px solid #ff9800; border-radius: 4px; padding: 5px;">
        
        <button onclick="adjustQuantity(1)" style="background: #ff9800; color: black; font-weight: bold; padding: 5px 10px; border-radius: 5px; border: none; cursor: pointer;">+</button>
    </div>

    <button class="add-to-cart" onclick="addToCart()">Add to Cart</button>
</div>

<script>
let selectedItem = {};

function showPopup(id, name, description, price, image) {
    selectedItem = { id, name, price };
    document.getElementById("popup-name").innerText = name;
    document.getElementById("popup-description").innerText = description;
    document.getElementById("popup-price").innerText = '₱' + parseFloat(price).toFixed(2);
    document.getElementById("popup-image").src = image;
    document.getElementById("quantity").value = 1;
    document.getElementById("popup").style.display = "block";
    document.getElementById("overlay").style.display = "block";
}

function closePopup() {
    document.getElementById("popup").style.display = "none";
    document.getElementById("overlay").style.display = "none";
}

function adjustQuantity(change) {
    const qtyInput = document.getElementById("quantity");
    let quantity = parseInt(qtyInput.value) || 1;
    quantity += change;
    if (quantity < 1) quantity = 1;
    qtyInput.value = quantity;
}

function addToCart() {
    const quantity = document.getElementById("quantity").value;
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "add_to_cart.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {
            document.getElementById("cart-count").innerText = xhr.responseText;
            alert("Added to cart!");
            closePopup();
        }
    };

    xhr.send(`id=${selectedItem.id}&name=${encodeURIComponent(selectedItem.name)}&price=${selectedItem.price}&quantity=${quantity}`);
}

function filterCategory(category) {
    document.getElementById('appetizer-section').style.display = (category === 'all' || category === 'appetizer') ? 'block' : 'none';
    document.getElementById('main-section').style.display = (category === 'all' || category === 'main') ? 'block' : 'none';
    document.getElementById('dessert-section').style.display = (category === 'all' || category === 'dessert') ? 'block' : 'none';
}
</script>

</body>
</html>
