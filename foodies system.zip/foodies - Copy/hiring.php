<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Job & Grab - Hiring</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&family=Pacifico&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins', sans-serif;
        background: url("imahe/mama.jpg") no-repeat center center fixed;
        background-size: cover;
        color: #fff;
        margin: 0;
        min-height: 100vh;
        display: flex;
        flex-direction: column;
    }
    header {
        background: rgba(0, 0, 0, 0.8);
        padding: 20px;
        text-align: center;
        font-size: 28px;
        color: #ff8800;
        font-family: 'Pacifico', cursive;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
        position: relative;
    }
    .back-btn {
        position: absolute;
        left: 20px;
        top: 50%;
        transform: translateY(-50%);
        background: linear-gradient(135deg, #ff8800, #ff6600);
        color: #fff;
        padding: 8px 15px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        cursor: pointer;
        box-shadow: 0 0 10px rgba(255, 136, 0, 0.6);
        transition: transform 0.3s, background 0.3s;
        text-decoration: none;
        font-weight: bold;
    }
    .back-btn:hover {
        transform: scale(1.05);
        background: linear-gradient(135deg, #ff6600, #cc5200);
    }
    .container {
        max-width: 800px;
        margin: 40px auto;
        background: rgba(0, 0, 0, 0.85);
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 25px rgba(255, 136, 0, 0.5);
        text-align: center;
        animation: fadeIn 1s ease;
    }
    .container h2 {
        font-family: 'Pacifico', cursive;
        font-size: 32px;
        color: #ff8800;
        margin-bottom: 20px;
    }
    .container p {
        font-size: 18px;
        color: #ddd;
        margin-bottom: 30px;
    }
    .apply-btn {
        background: linear-gradient(135deg, #ff8800, #ff6600);
        color: #fff;
        padding: 12px 25px;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        cursor: pointer;
        box-shadow: 0 0 15px rgba(255, 136, 0, 0.6);
        transition: transform 0.3s, background 0.3s;
    }
    .apply-btn:hover {
        transform: scale(1.05);
        background: linear-gradient(135deg, #ff6600, #cc5200);
    }
    footer {
        background: rgba(0, 0, 0, 0.8);
        padding: 15px;
        color: #fff;
        text-align: center;
        margin-top: auto;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(-20px); }
        to { opacity: 1; transform: translateY(0); }
    }
</style>
</head>
<body>

<header>
    <a href="applicants.php" class="back-btn">⬅ Back</a>
    Join Our Team 🇵🇭
</header>

<div class="container">
    <h2>We're Hiring at Job & Grab!</h2>
    <p>Passionate ka ba sa food delivery? Looking for flexible work opportunities? Apply now and be part of our growing family!</p>
    
    <button class="apply-btn" onclick="window.location.href='application_form.php'">Apply Now</button>
</div>

<footer>
    &copy; 2025 Job & Grab. All rights reserved.
</footer>

</body>
</html>
