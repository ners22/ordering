<?php
session_start();
include('config.php'); // Database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $fullname = trim($_POST['fullname']);
    $contact = trim($_POST['contact']);
    $email = trim($_POST['email']);
    $position = trim($_POST['position']);
    $message = trim($_POST['message']);

    // Basic validation
    if (empty($fullname) || empty($contact) || empty($email) || empty($position) || empty($message)) {
        echo "<script>alert('Please fill in all fields.'); window.history.back();</script>";
        exit;
    }

    // Insert data matching your table columns
    $stmt = $conn->prepare("INSERT INTO applications (fullname, contact, email, position, message, applied_at) VALUES (?, ?, ?, ?, ?, NOW())");
    $stmt->bind_param("sssss", $fullname, $contact, $email, $position, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Application submitted successfully! Maraming Salamat 😊'); window.location.href='hiring.php';</script>";
    } else {
        echo "<script>alert('Something went wrong. Please try again.'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();

} else {
    header("Location: application_form.php");
    exit;
}
?>
