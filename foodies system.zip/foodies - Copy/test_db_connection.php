<?php
// Test database connection using config.php
include 'config.php';

if ($conn && !$conn->connect_error) {
    echo "SUCCESS: Connected to the 'system_food' database.";
} else {
    echo "ERROR: Could not connect to the database. " . $conn->connect_error;
}
?> 