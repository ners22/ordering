<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save order details (You can store in DB if needed)
    $_SESSION['order_details'] = [
        'full_name' => $_POST['full_name'],
        'email' => $_POST['email_address'],
        'shipping_address' => $_POST['shipping_address'],
        'phone_number' => $_POST['phone_number'],
        'cart_items' => isset($_SESSION['cart']) ? $_SESSION['cart'] : [],
        'total_price' => array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $_SESSION['cart'] ?? [])),
    ];

    // Redirect to payment page
    header("Location: payment.php");
    exit;
}
?>
