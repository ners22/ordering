<?php
session_start();

// Optional: Require admin login
// if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
//     header("Location: login.php");
//     exit();
// }

include 'config.php';  // Include your database connection here

// Place this at the very top, before any HTML or whitespace
if (isset($_POST['delete_user'])) {
    header('Content-Type: application/json');
    ob_clean(); // Clean any previous output
    $user_id = $_POST['user_id'];
    require_once 'config.php';

    // Delete related records first
    $conn->query("DELETE FROM cart WHERE user_id = $user_id");
    $conn->query("DELETE FROM orders WHERE user_id = $user_id");
    $conn->query("DELETE FROM payments WHERE user_id = $user_id");
    $conn->query("DELETE FROM login_logs WHERE user_id = $user_id");
    $conn->query("DELETE FROM restaurants WHERE owner_id = $user_id");

    // Now delete the user
    $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }
    exit();
}

// Handle update request securely
if (isset($_POST['update_user'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
    $stmt->bind_param("sssi", $username, $email, $role, $id);
    $stmt->execute();
    exit();
}

// Handle add user request
if (isset($_POST['add_user'])) {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $username, $email, $password, $role);
    $stmt->execute();
    exit();
}

// Fetch users
$result = $conn->query("SELECT * FROM users");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Users</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; background-color: #121212; color: white; padding: 20px; }
        h2 { color: #ffa31a; font-size: 36px; text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; border: 1px solid #333; text-align: left; }
        th { background-color: #1a1a1a; color: #ffa31a; }
        tr:hover { background-color: #333; }
        .btn { padding: 5px 14px; border: none; cursor: pointer; font-weight: bold; border-radius: 4px; margin-right: 6px; }
        .edit-btn { background: #2a9d8f; color: white; }
        .delete-btn { background: #e63946; color: white; }
        .edit-btn:hover, .delete-btn:hover { opacity: 0.8; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7); }
        .modal-content { background: #1a1a1a; padding: 20px; margin: 15% auto; width: 30%; border-radius: 5px; }
        .close { color: #ffa31a; float: right; font-size: 24px; cursor: pointer; }
        input[type="text"], input[type="email"], input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #333; background-color: #333; color: white; }
        select { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #333; background-color: #333; color: white; }
        input[type="submit"] { background-color: #ffa31a; color: #121212; padding: 10px 20px; border: none; cursor: pointer; font-weight: bold; }
        .back-btn { display: inline-block; margin-top: 10px; padding: 10px 20px; background: #264653; color: white; text-decoration: none; font-weight: bold; }
        .back-btn:hover { background-color: #ffa31a; color: black; }
    </style>
</head>
<body>

<h2>Manage Users</h2>

<table>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th>Actions</th>
    </tr>
    <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= htmlspecialchars($row['id']) ?></td>
            <td><?= htmlspecialchars($row['username']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['role']) ?></td>
            <td>
                <button class="btn edit-btn" onclick="openEditModal(<?= $row['id'] ?>, '<?= htmlspecialchars($row['username'], ENT_QUOTES) ?>', '<?= htmlspecialchars($row['email'], ENT_QUOTES) ?>', '<?= $row['role'] ?>')">Edit</button>
                <button class="btn delete-btn" onclick="deleteUser(<?= $row['id'] ?>)">Delete</button>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<a href="admin.php" class="back-btn">Back to Home</a>

<!-- Edit User Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeEditModal()">&times;</span>
        <h3>Edit User</h3>
        <form id="editForm">
            <input type="hidden" id="edit_id" name="id">
            <label>Username:</label>
            <input type="text" id="edit_username" name="username" required>
            <label>Email:</label>
            <input type="email" id="edit_email" name="email" required>
            <label>Role:</label>
            <select id="edit_role" name="role" required>
                <option value="admin">Admin</option>
                <option value="customer">Customer</option>
                <option value="rider">Rider</option>
            </select>
            <input type="submit" value="Update">
        </form>
    </div>
</div>

<script>
    // Open and Close Modal Functions
    function openEditModal(id, username, email, role) {
        $("#edit_id").val(id);
        $("#edit_username").val(username);
        $("#edit_email").val(email);
        $("#edit_role").val(role);
        $("#editModal").fadeIn();
    }

    function closeEditModal() {
        $("#editModal").fadeOut();
    }

    // AJAX form handling for updating users
    $("#editForm").submit(function(e) {
        e.preventDefault();
        $.post("manage_users.php", $(this).serialize() + "&update_user=1", function() {
            location.reload();
        });
    });

    // Add deleteUser function
    function deleteUser(id) {
        if (confirm('Are you sure you want to delete this user?')) {
            $.post('manage_users.php', { delete_user: 1, user_id: id }, function(response) {
                try {
                    var res = JSON.parse(response);
                    if (res.success) {
                        // Remove the row from the table
                        $("button.delete-btn[onclick='deleteUser(" + id + ")']").closest('tr').fadeOut(400, function() { $(this).remove(); });
                    } else {
                        alert('Delete failed: ' + (res.error || 'Unknown error.'));
                    }
                } catch (e) {
                    alert('Delete failed: Invalid server response.');
                }
            });
        }
    }

    // Optional: Close modal when clicking outside
    $(window).on('click', function(e) {
        if ($(e.target).is('#editModal')) {
            closeEditModal();
        }
    });
</script>

