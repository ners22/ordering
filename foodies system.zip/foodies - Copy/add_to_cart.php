<?php
session_start();
include 'config.php';

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$user_id = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : null;

if (isset($_POST['id'], $_POST['name'], $_POST['price'], $_POST['quantity'])) {
    $id = intval($_POST['id']);
    $name = $_POST['name'];
    $price = floatval($_POST['price']);
    $quantity = max(1, (int)$_POST['quantity']); // Ensure minimum 1

    $found = false;

    // Search if item exists, update quantity in session
    foreach ($_SESSION['cart'] as &$item) {
        if ($item['id'] == $id) {
            $item['quantity'] += $quantity;
            $found = true;
            break;
        }
    }
    unset($item); // Avoid reference bugs

    // If not found, add new item to session
    if (!$found) {
        $_SESSION['cart'][] = [
            'id' => $id,
            'name' => $name,
            'price' => $price,
            'quantity' => $quantity
        ];
    }

    // If user is logged in, sync to database
    if ($user_id) {
        // Check if item already exists in cart for this user
        $stmt = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND menu_id = ?");
        $stmt->bind_param("ii", $user_id, $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            // Update quantity
            $new_quantity = $row['quantity'] + $quantity;
            $update = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
            $update->bind_param("ii", $new_quantity, $row['id']);
            $update->execute();
            $update->close();
        } else {
            // Insert new row
            $insert = $conn->prepare("INSERT INTO cart (user_id, menu_id, quantity) VALUES (?, ?, ?)");
            $insert->bind_param("iii", $user_id, $id, $quantity);
            $insert->execute();
            $insert->close();
        }
        $stmt->close();
    }

    // Count total quantity for display
    $totalQuantity = 0;
    foreach ($_SESSION['cart'] as $item) {
        $totalQuantity += $item['quantity'];
    }

    echo $totalQuantity;
} else {
    echo 0;
}
?>
