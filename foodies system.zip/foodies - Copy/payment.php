<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "system_food");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch latest transaction orders (modify if you have a transaction_id)
$sql = "SELECT full_name, item, qty, price FROM checkout_process ORDER BY id DESC";
$result = $conn->query($sql);

$orders = [];
$grand_total = 0;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $row['qty'] = (int) $row['qty'];
        $row['price'] = (float) $row['price'];
        $row['total_price'] = $row['qty'] * $row['price'];
        $grand_total += $row['total_price'];
        $orders[] = $row;
    }
} else {
    $orders = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Details</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            color: #fff;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #1a1a1a;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            box-shadow: 0 4px 10px rgba(255, 102, 0, 0.3);
            max-width: 500px;
            width: 100%;
            margin-bottom: 20px;
        }
        h2 {
            color: #ff8800;
        }
        table {
            width: 100%;
            color: #ddd;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #555;
        }
        th {
            color: #ff8800;
        }
        .total {
            font-weight: bold;
            color: #ff8800;
        }
        .btn-container {
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            background-color: #ff8800;
            border: none;
            color: white;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            margin: 5px;
        }
        .btn:hover {
            background-color: #ff6600;
        }
        .receipt {
            display: none;
            background: #fff;
            color: #000;
            padding: 20px;
            width: 300px;
            text-align: left;
            border: 1px solid #000;
        }
        .receipt h2 {
            color: #000;
            text-align: center;
        }
    </style>
</head>
<body>

    <div class="container">
        <h2>Payment Details</h2>
        <div class="order-summary">
            <?php if ($orders): ?>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Item</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                    <?php foreach ($orders as $order): ?>
                        <tr>
                            <td><?= htmlspecialchars($order['full_name']) ?></td>
                            <td><?= htmlspecialchars($order['item']) ?></td>
                            <td><?= $order['qty'] ?></td>
                            <td>₱<?= number_format($order['price'], 2) ?></td>
                            <td>₱<?= number_format($order['total_price'], 2) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <tr class="total">
                        <th colspan="4">Grand Total:</th>
                        <th>₱<?= number_format($grand_total, 2) ?></th>
                    </tr>
                </table>
            <?php else: ?>
                <p>No orders found.</p>
            <?php endif; ?>
        </div>
        <div class="btn-container">
            <a href="checkout.php" class="btn">Back to Checkout</a>
            <a href="process_payment.php" class="btn">Proceed to Payment</a>
            <button class="btn" onclick="showReceipt()">🧾 Print Receipt</button>
        </div>
    </div>

    <!-- Resibo -->
    <div class="receipt" id="receipt">
        <h2>Receipt</h2>
        <p><strong>Order Date:</strong> <?= date("F j, Y, g:i a") ?></p>
        <hr>
        <table>
            <tr>
                <th>Item</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= htmlspecialchars($order['item']) ?></td>
                    <td><?= $order['qty'] ?></td>
                    <td>₱<?= number_format($order['price'], 2) ?></td>
                    <td>₱<?= number_format($order['total_price'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total">
                <th colspan="3">Grand Total:</th>
                <th>₱<?= number_format($grand_total, 2) ?></th>
            </tr>
        </table>
        <hr>
        <p style="text-align: center;">Thank you for your purchase! 🍽</p>
        <button class="btn" onclick="window.print()">🖨 Print</button>
    </div>

    <script>
        function showReceipt() {
            document.getElementById('receipt').style.display = 'block';
        }
    </script>

</body>
</html>

<?php
$conn->close();
?>
