<?php
// Include database configuration
include('config.php');

// Start the session
session_start();

// Fetch all products from the database
$sql = "SELECT * FROM products";
$result = $conn->query($sql);

// Check if products exist
if ($result->num_rows > 0) {
    $products = $result->fetch_all(MYSQLI_ASSOC);  // Fetch products as an associative array
} else {
    $products = [];
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
</head>
<body>
    <h1>View Products</h1>

    <?php if (empty($products)): ?>
        <p>No products available at the moment.</p>
    <?php else: ?>
        <!-- Display products in a grid -->
        <div style="display: flex; flex-wrap: wrap;">
            <?php foreach ($products as $product): ?>
                <div style="border: 1px solid #ccc; margin: 10px; padding: 10px; width: 200px; text-align: center;">
                    <?php if ($product['image']): ?>
                        <img src="images/<?= $product['image'] ?>" alt="<?= $product['name'] ?>" style="width: 100%; height: 150px; object-fit: cover;">
                    <?php else: ?>
                        <img src="images/default.jpg" alt="No Image" style="width: 100%; height: 150px; object-fit: cover;">
                    <?php endif; ?>
                    <h3><?= $product['name'] ?></h3>
                    <p><?= substr($product['description'], 0, 100) . '...' ?></p>  <!-- Display short description -->
                    <p><strong>$<?= number_format($product['price'], 2) ?></strong></p>
                    <a href="view_product.php?id=<?= $product['id'] ?>">View Details</a>  <!-- Link to product detail page -->
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</body>
</html>
