<?php
// Start session
session_start();

// Include database configuration
include('config.php');

// Check if order_id is set
if (!isset($_GET['order_id'])) {
    echo "Invalid order.";
    exit;
}

$order_id = $_GET['order_id'];

// Fetch order details
$sql = "SELECT * FROM orders WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Order not found.";
    exit;
}

$order = $result->fetch_assoc();

// Fetch order items
$sql = "SELECT * FROM order_items WHERE order_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $order_id);
$stmt->execute();
$order_items = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
</head>
<body>
    <h2>Order Confirmation</h2>
    <p>Thank you, <strong><?php echo htmlspecialchars($order['name']); ?></strong>! Your order has been placed.</p>
    <p>Order ID: <strong><?php echo $order['id']; ?></strong></p>
    <p>Total Amount: <strong>$<?php echo number_format($order['total_amount'], 2); ?></strong></p>
    <h3>Order Details</h3>
    <ul>
        <?php while ($item = $order_items->fetch_assoc()) { ?>
            <li><?php echo $item['item_name']; ?> (x<?php echo $item['quantity']; ?>) - $<?php echo number_format($item['price'], 2); ?></li>
        <?php } ?>
    </ul>
    <a href="menu.php">Back to Menu</a>
</body>
</html>

<?php
// Close database connection
$conn->close();
?>
