<?php
// Connect to your database
$conn = new mysqli("localhost", "root", "", "jobcafe");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "<h2>Test: Applicants with Name and Email</h2>";

$sql = "SELECT 
            a.id AS application_id,
            a.seeker_id,
            u.username,
            u.email,
            j.job_title,
            j.company_name,
            a.application_date
        FROM applied a
        LEFT JOIN users u ON a.seeker_id = u.id
        LEFT JOIN jobs j ON a.applied_job = j.id
        ORDER BY a.application_date DESC";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1' cellpadding='10'>";
    echo "<tr>
            <th>Application ID</th>
            <th>Seeker ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Job Title</th>
            <th>Company</th>
            <th>Applied Date</th>
          </tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row['application_id'] . "</td>
                <td>" . $row['seeker_id'] . "</td>
                <td>" . ($row['username'] ?? 'N/A') . "</td>
                <td>" . ($row['email'] ?? 'N/A') . "</td>
                <td>" . ($row['job_title'] ?? 'N/A') . "</td>
                <td>" . ($row['company_name'] ?? 'N/A') . "</td>
                <td>" . $row['application_date'] . "</td>
              </tr>";
    }

    echo "</table>";
} else {
    echo "<p>No applicants found.</p>";
}

$conn->close();
?>
